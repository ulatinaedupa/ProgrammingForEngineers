from djitellopy import tello
import time

drone = tello.Tello()       # instantiate tello
drone.connect()        # connect to tello drone
print(drone.get_battery())


drone.takeoff()

drone.send_rc_control(0, 0, 0, 10)
time.sleep(3)
drone.send_rc_control(0,0,0,0)
drone.land()