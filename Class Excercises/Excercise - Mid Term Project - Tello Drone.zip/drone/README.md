# drone

You will need a mirror clip to test the line follower.
https://www.thingiverse.com/thing:2911427