#### Data Engineering Test

The data engineering test consists in two parts.

Part I - SQL
Part 2 - Python

In part 1 you will start with a database, no secure, called excercise.db prepared in SQLite.
The .docx details the extraction and presentation of the data.

In part 2 you will get some python problems and will make simple algorithms to test your knowledge in python.